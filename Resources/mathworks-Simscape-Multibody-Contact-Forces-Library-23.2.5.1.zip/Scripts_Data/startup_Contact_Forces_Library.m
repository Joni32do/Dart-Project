% Startup for Simscape Multibody Contact Force Library
% Copyright 2014-2023 The MathWorks, Inc.

web('Contact_Forces_Demo_Script.html');
