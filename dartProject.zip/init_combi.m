%% initialize the muscle model
clear all
clc
init_muscle_MEF();
init_muscle_MEE();